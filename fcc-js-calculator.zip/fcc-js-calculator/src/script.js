// !! IMPORTANT README:

// You may add additional external JS and CSS as needed to complete the project, however the current external resource MUST remain in place for the tests to work. BABEL must also be left in place. 

/***********
INSTRUCTIONS:
  - Select the project you would 
    like to complete from the dropdown 
    menu.
  - Click the "RUN TESTS" button to
    run the tests against the blank 
    pen.
  - Click the "TESTS" button to see 
    the individual test cases. 
    (should all be failing at first)
  - Start coding! As you fulfill each
    test case, you will see them go   
    from red to green.
  - As you start to build out your 
    project, when tests are failing, 
    you should get helpful errors 
    along the way!
    ************/

// PLEASE NOTE: Adding global style rules using the * selector, or by adding rules to body {..} or html {..}, or to all elements within body or html, i.e. h1 {..}, has the potential to pollute the test suite's CSS. Try adding: * { color: red }, for a quick example!

// Once you have read the above messages, you can delete all comments. 

// React Comp App, initalize comp state and this comp, superprops calls parent class's constr with compoent props
// operator last clicked
// waitingForOperand flags if calculator is waiting for next operand
// expression: complete math expression being built
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      displayValue: '0',
      operator: null,
      previousValue: null,
      waitingForOperand: false,
      expression: '',
    };
  }

  // handleClick: called when number or decimal point clicked
  // Destructure displayValue & waitingForOperand
  // Prevents mult decimal
  // if waitingForOperand is true, update displayValue with buttonValue, resets waitingForOperand & append buttonValue to expression
  handleClick = (buttonValue) => {
    const { displayValue, waitingForOperand } = this.state;

    if (buttonValue === '.' && displayValue.includes('.')) {
      return;
    }

    if (waitingForOperand) {
      this.setState({
        displayValue: buttonValue,
        waitingForOperand: false,
        expression: this.state.expression + buttonValue,
      });
    } else {
      this.setState({
        displayValue: displayValue === '0' ? buttonValue : displayValue + buttonValue,
        expression: this.state.expression + buttonValue,
      });
    }
  };

  // Called when operator btn clicked
  // destrct displayValue, waitingForOperand, & expression from state
  // if waitingforOperand is true, handles conset operator clicks ---> if nextOperator is '-' & last char in expression is operator, change it to neg sign, otherwise replace last operator in expression with nextOperator
  handleOperatorClick = (nextOperator) => {
    const { displayValue, waitingForOperand, expression } = this.state;

    if (waitingForOperand) {
      if (nextOperator === '-' && /[+\-*/]$/.test(expression)) {
        this.setState({
          displayValue: nextOperator,
          waitingForOperand: false,
          expression: expression + nextOperator,
        });
      } else {
        this.setState({
          operator: nextOperator,
          expression: expression.replace(/[\+\-\*\/]+$/, nextOperator),
        });
      }
      return;
    }

    // if waitingForOperand is false, update previousValue with displayValue *parsed float* sets waitingForOperand to true, sets operator to nextOperator and changes nextOperator to expression
    this.setState({
      previousValue: parseFloat(displayValue),
      waitingForOperand: true,
      operator: nextOperator,
      expression: expression + nextOperator,
    });
  };

  // evaluateExpression evals math expression
  // Reg expression fulters the expression and join valid parts
  // evals the filtered expression using eval
  // return result or 'error' if eval fails
  evaluateExpression = (expression) => {
    try {
      var filtered = expression.match(/(\*|\+|\/|-)?(\.|\-)?\d+/g).join('');
      var sum = eval(filtered);
      return sum;
    } catch (error) {
      return 'Error';
    }
  };
  
  // handleEqualsClick when equals btn is clicked
  // evals the expression, updates 'displayValue' with result, & resets other state variables
  handleEqualsClick = () => {
    const { expression } = this.state;
    const result = this.evaluateExpression(expression);
    this.setState({
      displayValue: String(result),
      operator: null,
      previousValue: null,
      waitingForOperand: false,
      expression: String(result),
    });
  };

  // handleClear resets the state to its initial values when the clear btn is clicked
  handleClear = () => {
    this.setState({
      displayValue: '0',
      operator: null,
      previousValue: null,
      waitingForOperand: false,
      expression: '',
    });
  };

  // Render method returns the JSX to display the calculator
  // Render displayValue and btns for numbers, operators, decimal point, clear, and equals
  // attches click event handlers to each btn to handle user interactions
  render() {
    return (
      <div>
        <div id="display">{this.state.displayValue}</div>
        <button className="numbers" id="zero" onClick={() => this.handleClick('0')}>0</button>
        <button className="numbers" id="one" onClick={() => this.handleClick('1')}>1</button>
        <button className="numbers" id="two" onClick={() => this.handleClick('2')}>2</button>
        <button className="numbers" id="three" onClick={() => this.handleClick('3')}>3</button>
        <button className="numbers" id="four" onClick={() => this.handleClick('4')}>4</button>
        <button className="numbers" id="five" onClick={() => this.handleClick('5')}>5</button>
        <button className="numbers" id="six" onClick={() => this.handleClick('6')}>6</button>
        <button className="numbers" id="seven" onClick={() => this.handleClick('7')}>7</button>
        <button className="numbers" id="eight" onClick={() => this.handleClick('8')}>8</button>
        <button className="numbers" id="nine" onClick={() => this.handleClick('9')}>9</button>
        <button className="operators" id="add" onClick={() => this.handleOperatorClick('+')}>+</button>
        <button className="operators" id="subtract" onClick={() => this.handleOperatorClick('-')}>-</button>
        <button className="operators" id="multiply" onClick={() => this.handleOperatorClick('*')}>x</button>
        <button className="operators" id="divide" onClick={() => this.handleOperatorClick('/')}>/</button>
        <button className="decimalPoint" id="decimal" onClick={() => this.handleClick('.')}>.</button>
        <button className="clearButton" id="clear" onClick={this.handleClear}>AC</button>
        <button id="equals" onClick={this.handleEqualsClick}>=</button>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
