
// Array for the drum sounds test 3?
const drumPads = [
  { id: 'Heater-1', key: 'Q', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Heater-1.mp3', text: 'Heater-1'},
  { id: 'Heater-2', key: 'W', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Heater-2.mp3', text: 'Heater-2'},
  { id: 'Heater-3', key: 'E', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Heater-3.mp3', text: 'Heater-3'},
  { id: 'Heater-4', key: 'A', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Heater-4_1.mp3', text: 'Heater-4'},
  { id: 'Clap', key: 'S', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Heater-6.mp3', text: 'Clap'},
  { id: 'Open-HH', key: 'D', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Dsc_Oh.mp3', text: 'Open-HH'},
  { id: 'Kick-N-Hat', key: 'Z', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Kick_n_Hat.mp3', text: 'Kick-N-Hat'},
  { id: 'Kick', key: 'X', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/RP4_KICK_1.mp3', text: 'Kick'},
  { id: 'Closed-HH', key: 'C', audio: 'https://cdn.freecodecamp.org/testable-projects-fcc/audio/Cev_H2.mp3', text: 'Closed-HH'},
];

// Function to handle click events on drum pads
const playSound = (letter) => {
  // Select the audio element with the id matching the letter
  const audioElement = document.getElementById(letter);
  console.log(`Audio Element for ${letter}:`, audioElement);
  if (audioElement) {
    console.log(`Audio Element ${letter} has play method:`, typeof audioElement.play === 'function');
    audioElement.currentTime = 0; 
    audioElement.play().catch(error => console.error('Error playing sound:', error));
  } else {
    console.error(`No audio element found for ${letter}`);
  }
};


// Drumpad component
class DrumPad extends React.Component { 
  
  // will click button when the corresponding key pressed
  componentDidMount() {
  document.addEventListener('keydown', this.handleKeyPress);
} 
    
  // will UNclick button when the corresponding key pressed
 componentWillUnmount() {
   document.removeEventListener('keydown', this.handleKeyPress);
 }

  // event handler for the key is pressed down event
handleKeyPress = (e) => {
  if (e.key.toUpperCase() === this.props.letter) {
    this.handleClick();
  }
}
  // event handler when the click event occurs
handleClick = () => {
  this.props.handleDisplay(this.props.text);
  playSound(this.props.letter); // Pass the letter to playSound
} 
 
  //when drumpad or key pressed, handleClick is called and in turn playSound function with audio element
render() {
  return (
  <div className="drum-pad" id={this.props.id} onClick={this.handleClick}>
      {this.props.letter}
      <audio className="clip" id={this.props.letter} src={this.props.src}></audio>
      </div>
  );
}                                    
 }

// defines react component as App and extends React.Component
class App extends React.Component {
  constructor(props){
    super(props);
     this.state = {display: 'Click or Press a Key'};
  }
  
    
  // Method to Update State, takes display as arg and update comp state with new value display
  handleDisplay = (display) => this.setState({ display });
  
  // returns JSX to render comp
 render(){
  return(
    <div id='drum-machine'>
      <div id='display'>{this.state.display}</div>
      <div id='drum-pads'>
        {drumPads.map(d => (
          <DrumPad
            key={d.id}
            id={d.id}
            letter={d.key}
            src={d.audio}
            text={d.text}
            handleDisplay={this.handleDisplay}
          />   
        ))}
      </div>
    </div>
  );
}
}

//render App comp into the DOM element with the id of root
ReactDOM.render(<App />, document.getElementById("root"));
  