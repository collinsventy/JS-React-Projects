# Random Quote Machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/Collin-Sventy/pen/LYoPOqN](https://codepen.io/Collin-Sventy/pen/LYoPOqN).

Random Quote Machine as part of freeCodeCamp React Cert